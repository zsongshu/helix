/**
 * Helix implementation of participant classes 
 * 
 */
package com.linkedin.helix.participant;