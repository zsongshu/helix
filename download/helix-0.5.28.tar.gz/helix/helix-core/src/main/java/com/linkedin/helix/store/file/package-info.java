/**
 * Helix implementation of file-based property store (Deprecated)
 * 
 */
package com.linkedin.helix.store.file;