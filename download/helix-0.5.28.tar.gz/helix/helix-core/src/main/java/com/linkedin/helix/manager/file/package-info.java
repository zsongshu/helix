/**
 * A file-based implementation of Helix cluster manager (Deprecated)
 * 
 */
package com.linkedin.helix.manager.file;