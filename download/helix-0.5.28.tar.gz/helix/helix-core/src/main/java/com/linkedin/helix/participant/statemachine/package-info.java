/**
 * Helix state model definitions for participant
 * 
 */
package com.linkedin.helix.participant.statemachine;