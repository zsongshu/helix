/**
 * Helix default implementation for handling state transition messages and controller messages
 * 
 */
package com.linkedin.helix.messaging.handling;