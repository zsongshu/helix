/**
 * Helix default implementation of a cluster spectator
 * 
 */
package com.linkedin.helix.spectator;