/**
 * Helix message handling classes
 * 
 */
package com.linkedin.helix.messaging;