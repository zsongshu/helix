/**
 * Examples of using Helix cluster manager
 * 
 */
package com.linkedin.helix.examples;