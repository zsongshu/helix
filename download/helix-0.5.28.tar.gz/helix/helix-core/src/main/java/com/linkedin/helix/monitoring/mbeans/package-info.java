/**
 * Helix jmx bean classes
 * 
 */
package com.linkedin.helix.monitoring.mbeans;