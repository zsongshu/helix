/**
 * Helix application property store classes
 * 
 */
package com.linkedin.helix.store;