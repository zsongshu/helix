/**
 * Jsql processor for Helix
 * 
 */
package com.linkedin.helix.josql;