/**
 * Helix classes for all types of znodes
 * 
 */
package com.linkedin.helix.model;