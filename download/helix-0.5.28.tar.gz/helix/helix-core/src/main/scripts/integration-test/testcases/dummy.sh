#/bin/bash

echo "this is a dummy test for verify ExternalCommand works"


